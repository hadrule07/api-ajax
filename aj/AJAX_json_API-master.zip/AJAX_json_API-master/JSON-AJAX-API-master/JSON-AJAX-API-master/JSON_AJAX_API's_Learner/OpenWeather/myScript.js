/*This is my script for the open weather API*/

